# Falsification Record
- Claim ID / Scope:
- Counterexample:
- Kill signal / Method / Threshold / Time window:
- Result / Independent replication:
- Action if killed: delete / downgrade / split / revise
- Residuals:
