# Life Passport
- Candidate ID:
- Registered scale / time window / environment:
- Classification / confidence:

| Closure | Status | Evidence grade | Key intervention | Counterevidence |
|---|---|---|---|---|
| C1 Individuation | | | | |
| C2 Work / Energy | | | | |
| C3 Embodied Meaning | | | | |
| C4 Endogenous Purpose | | | | |
| C5 Rule Revision | | | | |
| C6 Lineage Closure | | | | |

- Causal SCC: Yes / Latent / Unknown / No
- Residuals:
- Kill Conditions:
- Repair / Reclassification action:
