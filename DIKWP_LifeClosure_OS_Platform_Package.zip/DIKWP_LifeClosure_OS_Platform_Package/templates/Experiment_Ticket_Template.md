# RVC Experiment Ticket
- Experiment ID / Candidate ID / Target closure:
- Hypothesis / Baseline / Intervention / Endpoint:
- Controls / Evidence grade sought / Safety grade:
- Rollback / Stop rule / Kill threshold:
- Data and code release plan:
