from docx import Document
from docx.shared import Pt, Cm, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.style import WD_STYLE_TYPE
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from pathlib import Path

BASE=Path('/mnt/data/DIKWP_LifeClosure_OS_Platform_Delivery'); DOCS=BASE/'docs'; DIAG=BASE/'diagrams'; DOCS.mkdir(exist_ok=True)
FONT='Noto Sans CJK SC'; NAVY='17365D'; TEAL='0F766E'; LIGHT='EAF2F8'; GRAY='475569'

def shade(cell,fill):
    tcPr=cell._tc.get_or_add_tcPr(); shd=tcPr.find(qn('w:shd'))
    if shd is None: shd=OxmlElement('w:shd'); tcPr.append(shd)
    shd.set(qn('w:fill'),fill)

def no_split(row):
    trPr=row._tr.get_or_add_trPr(); trPr.append(OxmlElement('w:cantSplit'))

def repeat_header(row):
    trPr=row._tr.get_or_add_trPr(); e=OxmlElement('w:tblHeader'); e.set(qn('w:val'),'true'); trPr.append(e)

def margins(cell):
    tcPr=cell._tc.get_or_add_tcPr(); tcMar=tcPr.first_child_found_in('w:tcMar')
    if tcMar is None: tcMar=OxmlElement('w:tcMar'); tcPr.append(tcMar)
    for n,v in [('top',80),('start',110),('bottom',80),('end',110)]:
        x=OxmlElement('w:'+n); x.set(qn('w:w'),str(v)); x.set(qn('w:type'),'dxa'); tcMar.append(x)

def setup(title,subtitle):
    d=Document(); s=d.sections[0]; s.top_margin=Cm(1.8);s.bottom_margin=Cm(1.8);s.left_margin=Cm(2.1);s.right_margin=Cm(2.1)
    st=d.styles['Normal'];st.font.name=FONT;st._element.rPr.rFonts.set(qn('w:eastAsia'),FONT);st.font.size=Pt(10.5);st.paragraph_format.line_spacing=1.35;st.paragraph_format.space_after=Pt(6)
    for n,size,col in [('Title',24,NAVY),('Subtitle',12,GRAY),('Heading 1',17,NAVY),('Heading 2',14,TEAL),('Heading 3',12,GRAY)]:
        x=d.styles[n];x.font.name=FONT;x._element.rPr.rFonts.set(qn('w:eastAsia'),FONT);x.font.size=Pt(size);x.font.color.rgb=RGBColor.from_string(col)
        if n.startswith('Heading'):x.font.bold=True;x.paragraph_format.space_before=Pt(12);x.paragraph_format.space_after=Pt(6)
    hp=s.header.paragraphs[0];hp.text='DIKWP LifeClosure OS | Recursive Viability Closure';hp.alignment=WD_ALIGN_PARAGRAPH.RIGHT
    for r in hp.runs:r.font.size=Pt(8);r.font.color.rgb=RGBColor.from_string(GRAY)
    fp=s.footer.paragraphs[0];fp.alignment=WD_ALIGN_PARAGRAPH.CENTER;r=fp.add_run('LifeClosure OS · research and engineering prototype · 2026');r.font.size=Pt(8);r.font.color.rgb=RGBColor.from_string(GRAY)
    p=d.add_paragraph(style='Title');p.alignment=WD_ALIGN_PARAGRAPH.CENTER;p.add_run(title)
    p=d.add_paragraph(style='Subtitle');p.alignment=WD_ALIGN_PARAGRAPH.CENTER;p.add_run(subtitle)
    p=d.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.CENTER;r=p.add_run('Independent synthesis, falsifiable definition and operational system');r.bold=True;r.font.color.rgb=RGBColor.from_string(TEAL)
    return d

def box(d,title,body):
    t=d.add_table(rows=2,cols=1);t.alignment=WD_TABLE_ALIGNMENT.CENTER;t.style='Table Grid';repeat_header(t.rows[0]);no_split(t.rows[0]);no_split(t.rows[1])
    shade(t.cell(0,0),NAVY);p=t.cell(0,0).paragraphs[0];p.alignment=WD_ALIGN_PARAGRAPH.CENTER;r=p.add_run(title);r.bold=True;r.font.color.rgb=RGBColor(255,255,255);r.font.size=Pt(12)
    shade(t.cell(1,0),LIGHT);margins(t.cell(1,0));r=t.cell(1,0).paragraphs[0].add_run(body);r.font.size=Pt(11);r.font.color.rgb=RGBColor.from_string(NAVY)
    d.add_paragraph()

def table(d,headers,rows,widths=None,fs=9):
    t=d.add_table(rows=1,cols=len(headers));t.style='Table Grid';t.alignment=WD_TABLE_ALIGNMENT.CENTER;t.autofit=False;repeat_header(t.rows[0]);no_split(t.rows[0])
    for i,h in enumerate(headers):
        c=t.rows[0].cells[i];shade(c,NAVY);margins(c);p=c.paragraphs[0];p.alignment=WD_ALIGN_PARAGRAPH.CENTER;r=p.add_run(h);r.bold=True;r.font.color.rgb=RGBColor(255,255,255);r.font.size=Pt(fs)
    for ri,row in enumerate(rows):
        rr=t.add_row();no_split(rr)
        for i,v in enumerate(row):
            c=rr.cells[i];margins(c);c.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
            if ri%2:shade(c,'F8FAFC')
            r=c.paragraphs[0].add_run(str(v));r.font.name=FONT;r._element.rPr.rFonts.set(qn('w:eastAsia'),FONT);r.font.size=Pt(fs)
    if widths:
        for rr in t.rows:
            for i,w in enumerate(widths):rr.cells[i].width=Cm(w)
    d.add_paragraph();return t

def bullets(d,items):
    for x in items:d.add_paragraph(x,style='List Bullet')

def numbered(d,items):
    for x in items:d.add_paragraph(x,style='List Number')

def source(d):
    p=d.add_paragraph();r=p.add_run('Primary source: Kofman et al., “Defining Life: A Conversation,” Organisms 9(1), 2026, pp. 11–47, DOI: 10.13133/2532-5876/19492. The paper is used as a structured map of unresolved positions rather than as a single settled theory.');r.italic=True;r.font.size=Pt(8.5);r.font.color.rgb=RGBColor.from_string(GRAY)

# README
D=setup('DIKWP LifeClosure OS','交付地图与快速启动指南')
box(D,'目标','将生命定义争论转化为可注册尺度、可执行扰动实验、可建立因果闭合图、可输出Life Passport并可被独立反证的统一研究接口。')
D.add_heading('快速启动',1);numbered(D,['阅读 01_Final_Theory_and_LifeClosure_OS.docx。','使用 02_Operational_Test_and_Consensus_Manual.docx 设计实验。','查看 03_Borderline_Cases_and_Research_Roadmap.docx 的边界案例和研发路线。','打开 prototype/index.html 生成离线 Life Passport。','使用 Excel 工作簿管理候选、证据、因果边、反证与路线图。'])
D.add_heading('最短最终解',1);box(D,'Recursive Viability Closure','生命是在明确尺度上，以物质—能量工作递归地产生自身边界和约束，使差异获得相对于自身可存续域的具身意义，并能依据历史修订至少部分适应规则的强连通因果闭合。个体生命由C1–C5定义；生命谱系再增加跨代重建与可遗传变异。')
D.add_heading('文件清单',1);table(D,['文件','用途'],[['01_Final_Theory_and_LifeClosure_OS.docx','最终理论、形式定义、系统蓝图与关键模块'],['02_Operational_Test_and_Consensus_Manual.docx','C1–C5测试、证据等级、分类与共识终止协议'],['03_Borderline_Cases_and_Research_Roadmap.docx','病毒、芽孢、火焰、LLM等案例与36个月路线'],['DIKWP_LifeClosure_Classification_Matrix.xlsx','仪表盘、候选、证据、因果边、Life Passport和Kill Matrix'],['prototype/index.html','离线评估原型'],['api / schemas / src / templates','接口、数据协议、演示代码和直接使用模板']],[7,9])
D.add_heading('边界',1);bullets(D,['“最终解”是可证伪的操作闭合，不是声称未来科学不能修订。','示例评分是先验演示，必须由实验与独立复现更新。','平台不替代生物安全、医学伦理、行星保护和实验室监管。'])
source(D);D.save(DOCS/'00_README_and_Delivery_Map.docx')

# Main theory and blueprint
D=setup('Recursive Viability Closure','关于“生命是什么”的最终操作解与LifeClosure OS蓝图');source(D)
D.add_heading('执行结论',1);box(D,'一句话','生命不是属性清单，而是因果拓扑：系统用物质—能量工作递归地产生自身边界、约束、意义、规范和规则修订机制，使其能够在变化中继续成为“这个系统”。')
D.add_heading('一、为什么附件讨论不闭环',1)
table(D,['混淆','争论表现','本方案拆分'],[['对象层级','个体、谱系、生态系统、生命总体混用','分别定义活的个体、休眠生命、生命依赖体、活的谱系和集体生命候选'],['定义/起源','“什么是生命”与“怎样起源”相互替代','定义给判定条件；起源解释闭合如何逐步形成'],['必要条件/实现','细胞、DNA、代谢、复制被当普适本质','视为地球生命实现闭合的工程机制'],['二元/连续','活或不活与生命度连续冲突','闭合拓扑二元；鲁棒性、范围、跨尺度深度连续'],['观察者/本体','边界由观察者选择，是否纯主观','观察者注册尺度；系统是否自生产边界由干预决定'],['属性/因果','罗列代谢、信息、学习、能动性','要求五类功能互相生产并形成强连通回路']],[3.2,5.8,7.0],8.6)
D.add_paragraph('附件第32—33页的形态空间图很好地展示了代谢、信息、空间、发育和计算复杂度的相对位置，但没有给出“哪条因果回路一旦闭合就跨入生命相”的判定。因此形态空间应作为生命度地图，而不是最终定义。')
D.add_heading('二、正式定义',1);box(D,'RVC定义','对候选系统S，在预先注册的尺度σ、时间窗τ与环境E下：若S能利用外界自由能与物质，递归地产生和修复使其个体化的边界与约束；将环境差异转化为相对于自身可存续状态的具身意义；以内部历史改变行动；并在反馈中修改至少部分自身适应规则，则S在该尺度与时间窗内是活的。')
D.add_paragraph('“可存续”不是观察者赋予的功利目标，而是系统结构自身产生的规范差异：某些状态支持边界、约束、记忆和修复过程继续存在，另一些状态使其解体。由此得到最低限度的内生目的。')
D.add_heading('三、五类闭合',1)
if (DIAG/'life_closure_core.png').exists():
    p=D.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.CENTER;sh=p.add_run().add_picture(str(DIAG/'life_closure_core.png'),width=Inches(6.5));sh._inline.docPr.set('descr','Five causal closures forming Recursive Viability Closure');sh._inline.docPr.set('title','Recursive Viability Closure core')
table(D,['闭合','核心问题','排除的伪生命'],[['C1 边界闭合','选择性界面是否由系统内部过程产生、维持和修复？','外部容器或平台维持的边界'],['C2 功闭合','系统是否把能量和物质定向用于重建自身约束？','只耗散而不重建的火焰、飓风'],['C3 语义闭合','差异是否因对系统存续的后果而有意义，并被历史保存？','无自身利害的传感器和数据库'],['C4 规范闭合','系统是否生成自身的好/坏状态和纠偏行动？','只优化外部损失函数的工具'],['C5 反身闭合','系统是否能修改至少部分解释、控制或适应规则？','固定反馈控制器或外部更新模型']],[3.1,7.6,6.1],8.8)
D.add_paragraph('关键不是五项分别得分高，而是它们形成覆盖全部节点的强连通因果分量：边界控制能流，能流重建约束，语义与记忆指导行动，规范评价行动后果，反身修改再重构边界、能流、语义与行动。')
D.add_heading('四、形式化',1);box(D,'判定式','Alive(S | σ, τ, E) = 1，当且仅当 C1 ∧ C2 ∧ C3 ∧ C4 ∧ C5 均得到可重复干预证据支持，并且 {边界B、工作W、记忆M、可存续域V/策略π、元动态μ} 在因果图中形成覆盖全部节点的强连通闭合。')
D.add_paragraph('是否活着是拓扑判定；多么有生命力是连续测量。生命鲁棒性可以由最弱闭合的可靠性、恢复速度、冗余、环境范围、学习深度、时间跨度和跨尺度协调组成。')
D.add_heading('五、DIKWP同构',1)
table(D,['层','生命对应','成立条件'],[['D','浓度、膜电位、损伤、资源和扰动','物理差异被系统界面接收'],['I','被区分为有利、危险、可食、可修复等差异','差异对可存续域有可测后果'],['K','基因调控、表观遗传、免疫记忆、网络结构、学习','历史在系统内部留下可调用结构'],['W','在资源、风险和冲突中选择修复、逃避、休眠、合作等','行动表现情境权衡而非固定反射'],['P','由维持和扩展递归闭合生成的内生规范','目的来自系统继续生产自身条件']],[2.2,7.4,7.2],8.6)
D.add_paragraph('生命可因此定义为“物理具身的DIKWP闭合”：数据经系统利害成为信息，历史成为知识，行动权衡成为智慧，递归自生产形成内生目的；目的再反向选择数据、更新知识并修订规则。')
D.add_heading('六、个体、谱系和休眠',1)
table(D,['类别','条件','解决的争论'],[['活的个体','C1–C5在一个个体尺度运行','骡、工蚁、绝育个体不因不繁殖而失去生命'],['休眠生命','活动闭合暂停，但内部保存自主重启完整闭合的结构','芽孢与死亡分开'],['活的谱系','后继系统重建C1–C5，具有可遗传变异，并扩展适应空间','复制、进化、开放式新颖性属于谱系层'],['生命依赖体','关键闭合由另一生命系统提供','病毒、某些寄生复制体'],['前生命系统','部分闭合但无完整RVC','自催化集、原始囊泡等生命起源中间态']],[3.4,7,6.2],8.8)
D.add_heading('七、观察者问题的最终处理',1);box(D,'关系客观性','观察者必须选择尺度、时间窗和候选边界，这是测量注册；但注册后，边界是否由系统自己维持、五类闭合是否因果成立，不由观察者偏好决定。因此生命既不是绝对对象主义，也不是任意主观标签，而是可复现的关系客观性。')
D.add_heading('八、关键系统：LifeClosure OS',1)
if (DIAG/'life_decision_pipeline.png').exists():
    p=D.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.CENTER;sh=p.add_run().add_picture(str(DIAG/'life_decision_pipeline.png'),width=Inches(6.7));sh._inline.docPr.set('descr','LifeClosure OS workflow from boundary registration through falsification review');sh._inline.docPr.set('title','LifeClosure OS decision pipeline')
modules=[('Observer & Scale Registry','登记尺度、时间窗、环境壳层和测量能力。'),('Causal Boundary Finder','识别由系统选择性调节且内部维护的因果瓶颈。'),('Constraint and Work Closure Engine','追踪自由能、物质和约束的互相生产。'),('Embodied Meaning Engine','检验差异是否相对可存续域产生历史依赖的作用。'),('Normativity Detector','识别内生误差信号、恢复目标和目标冲突权衡。'),('Rule Revision Lab','检验系统是否改变适应规则而非仅在预设响应中选择。'),('Dormancy and Lineage Lab','区分休眠、依赖体和谱系重建。'),('Causal SCC Engine','根据干预证据判断强连通闭合。'),('Life Passport Generator','输出分类、证据、残差、Kill Conditions和回放包。'),('Consensus Termination Board','把术语异议转成具体节点、因果边和反证任务。'),('Synthetic Life Design Studio','根据缺失闭合生成最小构造路线。'),('Life Morphospace Atlas','保存连续鲁棒性和跨尺度多样性。')]
for a,b in modules:
    p=D.add_paragraph();r=p.add_run(a);r.bold=True;r.font.color.rgb=RGBColor.from_string(TEAL);p.add_run(' — '+b)
D.add_heading('九、系统对象和技术架构',1)
table(D,['对象','关键字段'],[['CandidateSystem','基质、组件、已知依赖、对象范围'],['ObserverBoundary','尺度、时间窗、环境、排除项、测量能力'],['ClosureEvidence','闭合类型、命题、方法、结果、证据等级、反证'],['CausalEdge','源节点、目标节点、干预、效应、复现状态'],['LifePassport','分类、C1–C6、SCC、鲁棒性、残差、Kill'],['ExperimentTicket','假设、基线、干预、终点、对照、安全等级'],['ReplayBundle','数据哈希、协议、代码、模型、人工审查和输出']],[4.2,12],9)
table(D,['层','建议技术'],[['前端','React/Next.js；Cytoscape.js因果图；离线单页原型'],['后端','FastAPI；任务队列；实验和评审工作流'],['数据','PostgreSQL+JSONB；对象存储；可选Neo4j'],['分析','NetworkX强连通；DoWhy/causal-learn/Tigramite干预分析'],['可复现','DVC/DataLad；容器；数据和软件哈希'],['治理','最小权限、审计日志、Kill Board、版本化本体']],[3.2,13],9)
D.add_page_break();D.add_heading('十、最终压缩版',1);box(D,'最终答案','生命是能够在开放环境中，以物质—能量工作递归地产生自身边界和约束，使差异获得系统自身的意义，形成内生可存续规范，并依据历史修订自身适应规则的过程。个体生命由五类闭合定义；生命谱系再以可遗传方式重建并扩展这种闭合。');bullets(D,['二元层：在预注册尺度与时间窗内，五闭合强连通则为活；否则不构成独立活体。','连续层：生命度描述闭合的鲁棒性、恢复速度、环境范围、学习深度和跨尺度协调。','终结层：所谓终结讨论，是把词义争论转化为可干预、可复现、可反证的因果任务，而不是禁止理论在新证据下修订。'])
D.save(DOCS/'01_Final_Theory_and_LifeClosure_OS.docx')

# Operational manual
D=setup('LifeClosure Operational Manual','C1–C5实验、分类算法、反证与共识终止协议')
box(D,'操作原则','生命判定不能由“看起来像生命”或平均分决定。必须注册系统边界，通过干预证据证明五类闭合互相生产，并在因果图上形成强连通分量。')
D.add_heading('一、预注册',1);table(D,['字段','要求'],[['候选系统','对象、组件、基质、状态'],['尺度σ','空间范围和组织层级'],['时间窗τ','秒、生命周期或世代'],['环境E','资源、宿主、外部维护、网络和操作者'],['问题类型','个体、休眠、谱系、集体或人工生命'],['基线与对照','非生命耗散体、固定控制器、外部维护体'],['安全限制','生物安全、伦理、隐私、行星保护']],[4.2,12],9)
D.add_heading('二、证据等级',1);table(D,['等级','含义','用途'],[['E0','直觉、比喻、未验证理论','生成假设'],['E1','单次观察或相关性','支持局部特征'],['E2','有对照的重复观察','支持条件存在'],['E3','干预性因果证据','建立闭合边'],['E4','跨方法或跨实验室复现','核心判定'],['E5','跨基质与跨尺度复现','普适理论支持']],[2.3,7.4,6.5],9)
for title,rows in [
('三、C1 边界闭合',[['选择性交换','改变资源/毒物/信号并测跨界通量','系统主动调节，而非被动扩散'],['边界损伤—修复','局部可逆损伤','内部过程重建界面'],['边界生成','追踪生长/分裂中新边界来源','新界面由系统工作产生'],['反证','边界完全由外部容器或操作者维持','改判依赖体或非生命']]),
('四、C2 功闭合',[['能量—工作映射','追踪能量到修复和约束合成','能量被定向用于重建'],['物质更新','标记组件替换','更换部件仍维持组织身份'],['被动衰减对比','停止/恢复输入','主动维持显著超过材料惯性'],['反证','只耗散不重建完整约束','非生命耗散结构']]),
('五、C3 语义闭合',[['状态依赖意义','相同刺激作用于不同内部状态','响应因存续后果和历史而异'],['历史写入','训练/暴露后再测','内部物理变化影响未来行为'],['错误信息成本','施加误导信号','错误解释降低存续，纠错恢复'],['反证','响应与可存续和历史无关','无具身意义']]),
('六、C4 规范闭合',[['偏离—纠偏','使关键变量偏离范围','内生误差信号和恢复'],['目标冲突','资源、修复、增长冲突','按情境权衡而非单指标'],['撤去外部奖励','移除任务/奖励','仍维护自身闭合'],['反证','好坏完全由外部控制器定义','无内生规范']]),
('七、C5 反身闭合',[['新颖扰动','施加预设响应外情境','产生并保存新策略'],['规则追踪','比较前后控制映射','至少一条规则由系统内部改写'],['元适应','重复任务族','改变“如何学习/恢复”'],['反证','所有改变需外部重编程','固定或受控系统']])]:
    D.add_heading(title,1);table(D,['测试','操作','支持/反证'],rows,[3.6,6.2,7.0],8.8)
D.add_heading('八、强连通判定',1);bullets(D,['C1→C2：边界控制资源；C2→C1：工作重建边界。','C1/C2→C3：界面和能量使差异可编码；C3→C2：信息指导资源与修复。','C3→C4：历史使状态产生好坏差异；C4→C3：规范选择保存什么。','C4→C5：存续失败触发规则改变；C5→其余：规则改变重构整个闭合。'])
box(D,'门槛','属性得分只能表示证据质量，不能代替因果闭合。若某一关键节点由外部提供，候选不是独立生命。')
D.add_heading('九、分类算法',1);table(D,['类别','规则'],[['Alive–Active','C1–C5运行且形成强连通闭合'],['Alive–Dormant','活动闭合暂停；内部保存自主重启结构；无宿主补齐核心机器'],['Life-Dependent','关键自构、功或规范闭合由另一生命系统提供'],['Preliving','部分闭合和局部回路存在，但无完整RVC'],['Living Subsystem','局部尺度有闭合，但个体性依赖更高尺度'],['Nonliving Organized','复杂、耗散、复制或学习，但无完整RVC'],['Dead','曾有RVC，现不可恢复地解体']],[4.2,12],9)
D.add_heading('十、共识终止协议',1);numbered(D,['语义注册：术语先映射到对象、尺度和闭合。','主张分解：把“生命需要X”改写为“缺失X会断哪条因果边”。','证据分级：严格区分比喻、相关性、干预和复现。','反证承诺：支持者预先写出会改变观点的结果。','边界案例共测：至少一个已知生命、一个耗散体、一个复制体和一个人工系统。','少数报告：结论之外保留异议和残差。','阶段关闭：达到门槛后进入工作共识，直到Kill触发。','版本化修订：新理论通过新增、删除或重连闭合边进入系统。'])
D.add_heading('十一、核心Kill Conditions',1);table(D,['命题','Kill','动作'],[['C1–C5共同必要','公认生命可靠缺失一项','删除必要性或移至谱系/鲁棒性'],['反身闭合必要','最小生命无任何规则可塑性','弱化C5或移至谱系层'],['关系客观性','固定尺度后判定仍只靠偏好','承认更强观察者构成性'],['跨基质普适','内生规范被证明依赖特定生物化学','加入基质限制'],['RVC区分力','无法区分火焰、病毒、芽孢、细胞、AI','重构节点和边']],[4.3,6,6.2],8.8)
D.add_heading('十二、安全分级',1);table(D,['等级','范围','要求'],[['A0','文献、现有数据、离线模型','一般研究治理'],['A1','低风险物理/化学/软件模拟','标准实验控制'],['A2','低风险细胞、类器官、封闭机器人','伦理/生物安全审查'],['A3','可复制生物、环境释放、自主硬件','专门委员会、隔离、停止机制'],['A4','病原增强、不可逆释放、高影响人工生命','平台不提供执行指令，仅支持治理分析']],[2.4,7,7.1],8.8)
D.save(DOCS/'02_Operational_Test_and_Consensus_Manual.docx')

# Cases and roadmap
D=setup('LifeClosure Casebook and Roadmap','边界案例、Life Passport、MVP和36个月研发计划')
box(D,'说明','案例是RVC框架的示范性先验，必须被实验更新。确定的是判定程序，而不是每个对象的永久评分。')
D.add_heading('一、边界案例',1)
rows=[['细菌','Alive–Active','五类闭合可在细胞尺度运行'],['人/骡/工蚁','Alive–Active','个体不必繁殖；C1–C5完整'],['休眠芽孢','Alive–Dormant','闭合暂停但内部重启结构保留'],['病毒（宿主外）','Life-Dependent','功、自构和规范闭合依赖宿主'],['朊病毒','Nonliving propagator','模板传播但无独立边界、功和规范闭合'],['火焰/飓风','Nonliving Organized','有能流和反馈，无具身意义、规范和规则修订闭合'],['晶体','Nonliving Organized','生长/模板复制不足'],['自催化肽集','Preliving','有约束闭合雏形，缺语义、规范和反身适应'],['Xenobot','Preliving / subsystem candidate','需区分细胞生命与整体新个体'],['当前LLM','Nonliving cognitive tool','边界、能量、维护、记忆和目的由外部组织提供'],['自治自修机器人','Open Candidate','若自主维护资源、生成内生规范并改写规则，可跨基质成为生命'],['生态系统','Collective-life Candidate','需证明统一自构边界、整体规范和元动态']]
table(D,['对象','示范分类','理由'],rows,[4,4.5,10.8],8.5)
if (DIAG/'life_phase_map.png').exists():
    p=D.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.CENTER;sh=p.add_run().add_picture(str(DIAG/'life_phase_map.png'),width=Inches(6.6));sh._inline.docPr.set('descr','Illustrative phase map of self-construction and semantic normative closure for borderline cases');sh._inline.docPr.set('title','Life phase map')
D.add_heading('二、示范Life Passport：病毒',1);table(D,['字段','内容'],[['对象边界','单个病毒粒子，宿主外'],['分类','Life-Dependent'],['C1','衣壳存在但不能自主修复/重建'],['C2','无独立能量获取和合成工作'],['C3','基因组保存历史，但执行依赖宿主'],['C4','无独立可存续纠偏网络'],['C5','粒子自身不修订适应规则'],['残差','巨型病毒和细胞内复合体需更大尺度评估'],['Kill','若无宿主即可完成C1–C5，改判活跃生命']],[4,12],9)
D.add_heading('三、示范Life Passport：当前LLM',1);table(D,['字段','内容'],[['对象边界','模型权重+推理进程；排除人员和数据中心'],['分类','Nonliving cognitive tool'],['C1','软件边界由平台创建和恢复'],['C2','能源、硬件和维护由外部提供'],['C3','处理语义，但无与自身存续闭合相连的利害结构'],['C4','目标、奖励、部署和停机由人定义'],['C5','运行中自我修改受限，权重/权限外部更新'],['残差','未来具身长期代理需重新测试'],['Kill','若撤去外部任务后仍自主维护闭合和规则，当前分类失效']],[4,12],9)
D.add_heading('四、基准任务',1);table(D,['Benchmark','组合','区分'],[['B1耗散不等于生命','火焰/飓风/细菌','能流与完整RVC'],['B2复制不等于生命','晶体/病毒/细胞','模板复制与自构规范闭合'],['B3学习不等于生命','控制器/LLM/细菌/人','外部优化与内生规范'],['B4休眠不等于死亡','芽孢/种子/死细胞','内部重启与不可恢复解体'],['B5部件不等于个体','细胞/器官/个体/生态系统','尺度注册和新个体层级'],['B6人工不等于非生命','固定机器人/自修机器人','跨基质C1–C5'],['B7边界不是容器','囊泡/细胞/服务器容器','系统生产边界与外部封装'],['B8目的不是奖励','RL智能体/动物/细胞','外部目标与内生可存续域']],[4,6,7],8.8)
D.add_heading('五、12周MVP',1);table(D,['周','目标','交付'],[['1–2','冻结RVC术语、Schema、案例','定义、数据字典、基准'],['3–4','候选登记、证据账本、C1–C5表单','对象模型、前端表单'],['5–6','因果图和SCC计算','缺失边报告'],['7–8','分类器和Life Passport','分类、Residual、Kill'],['9–10','对抗案例和多人审查','盲评、争议板、复现状态'],['11–12','离线原型、API和公开演示','MVP、Replay、QA']],[2.2,5.8,9.5],8.8)
D.add_heading('六、36个月路线',1);table(D,['阶段','时间','重点','里程碑'],[['1','0–6月','理论冻结与回顾性案例','RVC 1.0、案例库、预注册'],['2','7–12月','非生命与前生命对照','火焰/自催化/控制器测试'],['3','13–18月','细胞、休眠与复合系统','跨实验室C1–C5协议'],['4','19–24月','人工系统和机器人','外部依赖撤除与规则修订测试'],['5','25–30月','天体生物学和跨基质','远程证据映射、误报模型'],['6','31–36月','国际共识与标准接口','Life Passport规范、开放联盟']],[2.1,3,6.5,8.7],8.8)
D.add_heading('七、团队',1);table(D,['角色','职责'],[['理论生物学/生命起源','约束闭合、代谢和谱系'],['细胞/系统生物学','修复、休眠、调控实验'],['复杂系统/热力学','能流、相变和因果边'],['认知科学/信息论','具身意义、记忆和规范'],['人工生命/机器人','跨基质与人工系统'],['因果推断/统计','干预设计和复现'],['哲学/科学史','概念边界和观察者'],['伦理/生物安全','高风险实验治理'],['软件/数据工程','平台、API和证据账本']],[5,12],9)
D.add_heading('八、首轮成果',1);bullets(D,['The Recursive Viability Closure Definition of Life。','A Cross-Substrate Life Passport Standard。','Testing Endogenous Normativity and Rule Revision in Minimal Systems。','Dormancy, Viruses and AI under a Two-Level Theory。','LifeClosure OS: Open Evidence and Falsification Infrastructure。'])
D.add_heading('九、最终立场',1);box(D,'工作共识','学术共同体无需等待不可争议的词典句子。只要接受生命的本体核心是递归生存闭合，属性和基质是实现方式，连续指标是鲁棒性描述，观察者负责注册尺度而非任意创造闭合，讨论即可从形而上空转进入累积科学。')
D.save(DOCS/'03_Borderline_Cases_and_Research_Roadmap.docx')

print([p.name for p in DOCS.glob('*.docx')])
