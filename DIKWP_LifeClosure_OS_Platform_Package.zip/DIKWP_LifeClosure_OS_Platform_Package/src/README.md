# Source

- `lifeclosure_demo.py`: dependency-free offline classification demonstration.
- `create_docs.py`: reproducible generator for the four DOCX documents; paths currently target the delivery directory and may be changed for another deployment.

The demo values are illustrative priors. They do not replace intervention experiments or independent replication.
