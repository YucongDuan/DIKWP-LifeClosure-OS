#!/usr/bin/env python3
from __future__ import annotations
import json,sys
from pathlib import Path
from statistics import mean

def classify(c):
    core=[float(c[f'C{i}']) for i in range(1,6)];avg=mean(core)
    if c.get('causal_scc')=='Yes' and min(core)>=.65:return 'Alive-Active'
    if c.get('causal_scc')=='Latent' and c.get('dormant_restart')=='High' and c.get('host_dependency')!='High':return 'Alive-Dormant'
    if c.get('host_dependency')=='High' and float(c.get('C6',0))>=.5:return 'Life-Dependent'
    if c.get('causal_scc')=='Unknown' and avg>=.55:return 'Open Candidate'
    if avg>=.25 and c['C1']>=.4 and c['C2']>=.4:return 'Preliving'
    return 'Nonliving Organized'

def main(path):
    cases=json.loads(Path(path).read_text(encoding='utf-8'));out=[]
    for c in cases:
        x=dict(c);x['classification']=classify(c);x['robustness']=round(mean(float(c[f'C{i}']) for i in range(1,7)),3);out.append(x)
    print(json.dumps(out,ensure_ascii=False,indent=2))
if __name__=='__main__':main(sys.argv[1] if len(sys.argv)>1 else str(Path(__file__).parents[1]/'data'/'sample_cases.json'))
