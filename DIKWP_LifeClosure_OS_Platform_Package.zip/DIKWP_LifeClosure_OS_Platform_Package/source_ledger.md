# Source Ledger

## Primary attached source

- Kofman, K. et al. (2026). **Defining Life: A Conversation**. *Organisms: Journal of Biological Sciences*, 9(1), 11-47. DOI: 10.13133/2532-5876/19492. Used as a structured map of unresolved positions, not as a single settled theory.

## Theoretical inputs distinguished and integrated by RVC

- Montévil, M. & Mossio, M. (2015). Biological organisation as closure of constraints. Used for constraint closure.
- Kauffman, S. A. & Roli, A. (2023). A third transition in science? Used for open-ended evolution, construction and changing phase spaces.
- Levin, M. (2022). Technological approach to mind everywhere. Used for multiscale agency and problem-space expansion.
- Stepney, S. (2023). Life as a cyber-bio-physical system. Used for changing state spaces, changing rules and meta-dynamics.
- Schrödinger, E. (1944). What Is Life? Used for far-from-equilibrium organization.
- Jonas, H. (2001). The Phenomenon of Life. Used for identity-through-material-turnover and needful freedom.

## Engineering inputs

- Yucong Duan open-source ecosystem: https://github.com/YucongDuan
- Yucong Duan ResearchGate profile: https://www.researchgate.net/profile/Yucong-Duan

These are used for DIKWP packetization, evidence ledgers, white-box audit, Kill Conditions and replay-bundle engineering patterns. Individual technical reports must be evaluated according to their publication and evidence status.
